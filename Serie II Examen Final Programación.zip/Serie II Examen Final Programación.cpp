/* Maderlaine Vanessa Aldana Martinez Carne 0909-20-6881
Ingenieria en Sistemas 3er. Semestre Universidad Mariano Galvez
Examen Final Programaci�n I*/

//Declaracion de libreras 
#include <iostream>
#include <conio.h>
#include <windows.h>
#include <stdlib.h>

using namespace std;

//Declaraci�n de variables
int spila;
int option;
int pila[1]; //Uso de vector

//funcion para el tama�o del vector
int tpila(){
  cout<<"\n\n\tIngrese el limite de datos a utilizar: "; 
  cin>>spila; //
}

//Ingreso de los datos 
int push(){ 
  cout<<"\n Funcion PUSH "; 
  cout<<endl;
  //funci�n para ingresar los datos
  for (int i=0; i<spila; i++){
    cout<<"     Ingrese la nota del estudiante " << i+1 << ": "; 
    cin>>pila[i]; //Visualizaci�n de los datos
  }
}

//Eliminar los datos 
int pop(){ 
  pila[spila-1] = 0; //agregar valor a la pila inicializando desde cero.
  cout<<"\n Funcion POP "<<endl<<endl;
  cout <<" La nota ha sido eliminada "; //Mensaje de confirmaci�n
  _getch();
}

//Visualizar los datos 
int visualizar(){
  do{                                           
    cout<<"\n     Calificacion del estudiante " << spila << ": " << pila[spila-1];
    spila--; }
    while (spila!=0);
    cout<<endl<<endl;
   _getch();
}

// funci�n principal main
int main(){ 
  do{ 
    system("cls"); // limpiar la pantalla
             //menu de opciones 
    cout<<endl;
    cout<<"\n\t         MENU PRINCIPAL          ";
    cout<<"\n\t*********************************";
    cout<<"\n\t* 1.- Establecer tamano de array *";
    cout<<"\n\t* 2.- Funcion PUSH               *";
    cout<<"\n\t* 3.- Funcion POP                *";
    cout<<"\n\t* 4.- Mostrar pila               *";
    cout<<"\n\t* 5.- Finalizar el programa      *";
    cout<<"\n\t*********************************";
    cout<<"\n\t Elije una Opcion: ";
    cin>>option; //leer opcion
    system("cls"); //limpiar la pantallla
    
    //Inicializaci�n de funci�n switch case para dar uso correcto al menu de opciones
    switch(option)
	{
      case 1: 
	  	system("cls"); //limpiar pantalla
        tpila(); //LLamando a la funcion tama�o de la pila
        break;
        
      case 2:
	  	system("cls"); //limpiar pantalla
        push(); //LLamando a la funcion push
        break;
        
      case 3:
	  	system("cls"); //limpiar pantalla
        pop(); //LLamando a la funcion pop
        break;
        
      case 4:
	  	system("cls"); //limpiar pantalla
        visualizar(); //LLamando a la funci�n visualizaci�n
        break;
        
      case 5: 
      	cout<< "Programa finalizado";
	  	break; //Finalizar programa
	  	
      default: // Muestra el mensaje de error al usuario
  cout<<"\tERROR: La opci�n seleccionada es incorrecta";
  _getch();//detener el programa para visualizar
   break; }    
  } while(option!=5);
}

/* Maderlaine Vanessa Aldana Martinez Carne 0909-20-6881
Ingenieria en Sistemas 3er. Semestre Universidad Mariano Galvez
Examen Final Programaci�n I*/
